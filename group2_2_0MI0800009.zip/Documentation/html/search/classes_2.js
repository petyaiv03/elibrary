var searchData=
[
  ['string_0',['String',['../class_string.html',1,'']]]
];
