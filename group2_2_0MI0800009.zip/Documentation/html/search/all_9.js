var searchData=
[
  ['removebook_0',['removeBook',['../class_library.html#a03226f55ad71f637693d48e8f23b2af6',1,'Library']]]
];
