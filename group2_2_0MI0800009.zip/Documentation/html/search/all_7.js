var searchData=
[
  ['operator_2b_0',['operator+',['../class_string.html#ac094f267da5e0cdc7559bb1fa163f650',1,'String']]],
  ['operator_3c_3c_1',['operator&lt;&lt;',['../class_book.html#ac2f0dd5fe295710cb9817dd4bc99c0d5',1,'Book::operator&lt;&lt;()'],['../class_string.html#ac76aa0ee6f35e8859acfa5fc35ba9acd',1,'String::operator&lt;&lt;()']]],
  ['operator_3d_2',['operator=',['../class_string.html#a734f34a0b7a42bcad30c368d6e8c5469',1,'String']]],
  ['operator_3e_3e_3',['operator&gt;&gt;',['../class_book.html#a55962d3fc34119fc7ff28ba4751bae5f',1,'Book::operator&gt;&gt;()'],['../class_string.html#a787513aecfb83e83fa23d594e3671696',1,'String::operator&gt;&gt;()']]]
];
