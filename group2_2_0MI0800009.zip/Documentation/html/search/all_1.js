var searchData=
[
  ['book_0',['Book',['../class_book.html',1,'Book'],['../class_book.html#a2eac9e235a08763158f78533f7a83e1f',1,'Book::Book()'],['../class_book.html#a3dc9d01b6e3107f6f7afbcba66cc6385',1,'Book::Book(String _author, String _title, String _file_name, String _resume, double _rating, String _ISBN)'],['../class_book.html#a15a37eb254af5c1db6467a7ee4cd20e9',1,'Book::Book(std::ifstream &amp;in)']]],
  ['bookserialize_1',['bookSerialize',['../class_book.html#a06991cff79ec0ed088999955d48e60a5',1,'Book']]]
];
