var searchData=
[
  ['operator_2b_0',['operator+',['../class_string.html#ac094f267da5e0cdc7559bb1fa163f650',1,'String']]],
  ['operator_3d_1',['operator=',['../class_string.html#a734f34a0b7a42bcad30c368d6e8c5469',1,'String']]]
];
