var searchData=
[
  ['createbook_0',['createBook',['../class_library.html#a24dfd4199ecb40a984f88541e6146173',1,'Library']]]
];
