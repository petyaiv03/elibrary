#include <iostream>
#include "commands.h"

int main()
{
	Commands();
	return 0;
}